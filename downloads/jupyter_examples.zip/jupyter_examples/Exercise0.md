## Make a new directory called jupyter_practice
## Change to that directory
## Make another directory inside it called logs
## Look at the file /projects/racs_training/resources/juptyer_rt.yml
## Look at the file /projects/racs_training/resources/build_jupyter_rt.srun
## Run the script /projects/racs_training/resources/build_jupyter_rt.srun as a slurm job
## Check the status of the job
## Look at the output files in the logs directory
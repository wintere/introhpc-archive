dictionary = {'a': 1}
print(dictionary['a']) # Should not Raise KeyError !!!
print("Hello World !!")

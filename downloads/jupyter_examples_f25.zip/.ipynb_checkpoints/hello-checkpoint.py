dictionary = {'a': 1}
print(dictionary['b']) # Should Raise KeyError !!!
print("Hello Wold !!")

This README file was generated on 19-09-2024 by Warsha Barde.

GENERAL INFORMATION

1. Title of Dataset: Individual Choices Shape Divergent Brains and Behaviors 

2. Author Information:
	Warsha Barde, Jonas Renner, Brett Emery, Shahrukh Khanzada, Xin Hu, Alexander Garthe, Annette E. Rünker, Hayder Amin, Gerd Kempermann

    Corresponding author:
    Prof Dr Gerd Kempermann
    German Center for Neurodegenerative Diseases (DZNE) Dresden
    Tatzberg 41, 01307 Dresden, Germany
    gerd.kempermann@dzne.de or gerd.kempermann@tu-dresden.de
    Phone: +49 351 210 463 700


3. Date of data collection (single date, range, approximate date): 2022-04-06 to 2022-06-08

4. Geographic location of data collection: German Center for Neurodegenerative Diseases (DZNE) Dresden, Dresden, Germany

5. Information about funding sources that supported the collection of the data: This project was in part supported by the grant “The mouse in the supermarket” from Volkswagen Foundation. The remainder of the project was supported by basic institutional funds.

6. Data description: 
    This dataset contains behavioral data from a study examining how individual choices shape brain structure and function in mice, beyond genetic and environmental factors. Using the IntelliCage (IC) system, a fully automated home-cage apparatus from TSE Systems, we tracked the exploratory, learning, and social behaviors of 16 genetically identical female mice over two months. The apparatus is equipped with four operant conditioning corners, each of which contains two water bottles with sweetened water as reward, two nosepoke holes, and doors allowing or denying access to the reward. The system, controlled by software, allowed us to create specific learning protocols where access to rewards was based on predefined combinations of factors, such as corner visits, nosepoke patterns, and individual mouse identity. The IC system recorded events such as corner visits, nosepokes, and licking behavior through RFID antennas, nosepoke sensors, and lickometers. Mice engaged in 10 self-paced, pre-programmed learning tasks, with each animal's behavior automatically recorded and time-stamped. The dataset includes raw event logs, detailing the time, duration, mouse ID, corner ID, and corresponding rewards for each behavioral event, providing a comprehensive look into individual learning trajectories.

    During the 10-day adaptation phase, mice were familiarized with the enclosure, presence of rewards at the corners, the requirement to nosepoke for a reward, and the time restrictions on reward access. The learning phase consisted of five main tasks with ten variations: Place Learning with 3 Correct Corners (PL3CC), Place Learning with 1 Correct Corner (PL1CC), Patrolling (with correct corners shifting either clockwise or anticlockwise), Reverse Patrolling (where the correct corner's direction was reversed), and the Serial Reversal Task, in which two diagonally opposite corners were rewarded and the assignment of correct corners was reversed every four days. Behavioral data was recorded automatically by the IntelliCage system, capturing detailed information about each mouse's visits to operant corners. Exploratory behavior during the adaptation phase was assessed through roaming entropy (RE). This metric was derived from the duration of visits to different corners and then converted into the probability of the mouse being located in a specific corner on a given day using Shannon entropy.  In the learning phase, the percentage of correct visits was used to track learning, where a correct visit was defined as a visit to a rewarded corner followed by more than one nosepoke, indicating reward-seeking behavior. Flexibility in adapting to new tasks was assessed by calculating how often mice visited previously correct corners after a task reversal.

DATA & FILE OVERVIEW

1. File List:

    A) Visit.txt
    B) Tasks.txt
    C) Animals.txt

2. Relationship between files, if important: None

3. Additional related data collected that was not included in the current data package: None

4. Are there multiple versions of the dataset? No

#########################################################################

DATA-SPECIFIC INFORMATION FOR: Visit.txt

The file gives detailed description of every behavioral event.
1. Number of variables: 27

2. Number of rows: 172197

3. Variable List:

    * VisitID: Sequential number of the visit within the whole experiment.
    * VisitOrder: "Order" is a counter of visits for each individual starting with 0.
    * Animal:  A unique identifier name for the mice
    * Tag: A unique RFID transponder number assigned to each mouse for tracking.
    * Sex: The sex of the animal. In this case all were female.
    * Group: Animals were assigned into two groups 'IC a' and 'IC b' for the patrolling and patrolling reversal tasks. 'IC a' performed the task in clockwise direction while 'IC b' in anti-clockwise direction. In the reversal task this direction was reversed.
    * Module: Refers to the specific task module.
    * Cage: IntelliCage allows simulatneous conductance of experiment in two cages. Identifier for the particular cage where the animal is housed or tested. In this case it is 1.
    * Corner: The Id of the corner of the cage where the visited.
    * CornerCondition: The condition or status of the corner, which includes a corner being programmed as either 'correct', 'incorrect' or 'neutral'.
    * PlaceError: Errors related to the animal’s visit to incorrect corner.
    * SideErrors: Errors related to the animal’s visit to incorrect side of the corner. Not used in this experiment.
    * TimeErrors: Errors related to the animal’s visit to the corner before stipulated time. Not used in this experiment.
    * ConditionErrors: Errors related to  animal’s visit to the corner with incorrect condition. Not used in this experiment.
    * NosepokeNumber: The number of times the animal pokes its nose into the nosepoke sensor.
    * NosepokeDuration: The total duration of the nosepoke events by the animal.
    * LickNumber: The number of times the animal licks water spout.
    * LickDuration: The total duration of licking events by the animal.
    * LickContactTime: The duration of contact time during licking behavior.
    * StartDate: The date when the visit started.
    * StartTime: The timestamp when the visit began.
    * StartTimecode: A coded representation of the start time.
    * EndDate: The date when the visit ended.
    * EndTime: The timestamp when the visit ended.
    * EndTimecode: A coded representation of the end time.
    * VisitDuration: The total duration of the visit, from start to end.
    * Session: Identifier for the specific experimental session in which the visit occurred.

4. Missing data codes: None

5. Specialized formats or other abbreviations used: None

#########################################################################

DATA-SPECIFIC INFORMATION FOR: Tasks.txt

The file details the specific tasks conducted each night.
1. Number of variables: 3

2. Number of cases/rows: 63

3. Variable List:

    * Date: Calendar date for experiment days
    * Night: Sequential order of nights in the experiment
    * Task: name of the task assigned for each night.
    
4. Missing data codes: NA (data not available)

5. Specialized formats or other abbreviations used: None

#########################################################################

DATA-SPECIFIC INFORMATION FOR: Animals.txt

This files contains the information on each mice.
1. Number of variables: 6

2. Number of cases/rows: 16

3. Variable List:

    * Animal:A unique identifier name for the mice
    * Tag: A unique RFID transponder number assigned to each mouse for tracking.
    * Sex:The sex of the animal. In this case all were female.
    * Group: Animals were assigned into two groups 'IC a' and 'IC b' for the patrolling and patrolling reversal tasks. 'IC a' performed the task in clockwise direction while 'IC b' in anti-clockwise direction. In the reversal task this direction was reversed.
    * CornerAssigned: Initial corner assigned to each mouse for randomization within corners.
4. Missing data codes: NA (data not applicable)

5. Specialized formats or other abbreviations used: None

#########################################################################


